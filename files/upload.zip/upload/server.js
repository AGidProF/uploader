const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 8080;

// Password for accessing protected pages
const USERNAME = 'xinoo'
const PASSWORD = 'undefined';

// Middleware for basic authentication
function auth(req, res, next) {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
        res.setHeader('WWW-Authenticate', 'Basic');
        return res.status(401).send('Authorization required');
    }

    const base64Credentials = authHeader.split(' ')[1];
    const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
    const [username, password] = credentials.split(':');

    if (username == USERNAME && password === PASSWORD) {
        next();
    } else {
        res.setHeader('WWW-Authenticate', 'Basic');
        res.status(401).send('Unauthorized');
    }
}

// Set up multer for file storage
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Middleware to serve static files
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Upload endpoint
app.post('/upload', upload.single('file'), (req, res) => {
    if (req.file) {
        const fileName = req.file.filename;
        const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${fileName}`;
        const downloadPageUrl = `${req.protocol}://${req.get('host')}/downloads/${fileName}`;

        console.log(`File uploaded: ${fileUrl}`);
        res.send(`File uploaded successfully. URL: <a href="${fileUrl}">${fileUrl}</a> | Download Page: <a href="${downloadPageUrl}">${downloadPageUrl}</a>`);
    } else {
        res.status(400).send('File upload failed.');
    }
});

// Endpoint to list all uploaded files
app.get('/listupload', (req, res) => {
    const uploadsDir = path.join(__dirname, 'uploads');
    fs.readdir(uploadsDir, (err, files) => {
        if (err) {
            res.status(500).send('Failed to list files.');
            return;
        }
        const fileUrls = files.map(file => ({
            url: `${req.protocol}://${req.get('host')}/uploads/${file}`,
            name: file
        }));
        res.json(fileUrls);
    });
});

// Serve list.html at /listupload-page endpoint with password protection
app.get('/listupload-page', auth, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'list.html'));
});

// Serve index.html with password protection
app.get('/', auth, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Serve dynamic download pages
app.get('/downloads/:filename', (req, res) => {
    const filename = req.params.filename;
    const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${filename}`;
    const fileExtension = filename.split('.').pop().toLowerCase();
    let fileIcon = '/icons/file-icon.png';

    if (['jpg', 'jpeg', 'png', 'gif', 'bmp'].includes(fileExtension)) {
        fileIcon = fileUrl; // Use the actual image as the icon
    } else if (fileExtension === 'pdf') {
        fileIcon = '/icons/pdf-icon.png';
    }

    const template = fs.readFileSync(path.join(__dirname, 'public', 'download_template.html'), 'utf8');
    const downloadPageContent = template
        .replace(/{{fileName}}/g, filename)
        .replace(/{{fileUrl}}/g, fileUrl)
        .replace(/{{fileIcon}}/g, fileIcon);

    res.send(downloadPageContent);
});

// Delete endpoint
app.delete('/delete/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);

    fs.unlink(filePath, (err) => {
        if (err) {
            res.json({ success: false, message: 'Failed to delete file.' });
            return;
        }

        res.json({ success: true, message: 'File deleted successfully.' });
    });
});

// Create the uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir);
}

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});